# Portafolio de Emeli Andreina Gonzalez

Este repositorio contiene un sitio web estático (`index.html`) para un portafolio personal.

## Publicar en GitHub Pages

1. Sube `index.html` al branch `main` de tu repositorio.
2. Ve a **Settings → Pages**.
3. En **Source**, elige **Main** y carpeta **/(root)**.
4. Guarda. Espera unos segundos y tu página estará en línea.

---

_¡Éxitos y sigue creando!_
